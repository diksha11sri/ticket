package com.sunsoft.sprint.entity;

public enum BookingStatus {
	AVAILABLE, BOOKED, BLOCKED;
}

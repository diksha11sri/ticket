package com.sunsoft.sprint.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sunsoft.sprint.entity.Ticket;
import com.sunsoft.sprint.service.TicketService;



@RestController
@RequestMapping(value="/ticket")
public class TicketController {
	@Autowired
	TicketService ticketService;
	
	@GetMapping("/all")
	public List<Ticket> showAllTickets()
	{
		return ticketService.showAllTickets();
	}
	
	@DeleteMapping("{ticketId}")
	public void deleteTicket(@PathVariable int ticketId) {
		ticketService.deleteTicket(ticketId);

	}
	
	

}

package com.sunsoft.sprint.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sunsoft.sprint.entity.Ticket;
import com.sunsoft.sprint.repository.TicketRepository;

@Component
public class TicketDaoImpl implements TicketDao{

	@Autowired
	TicketRepository ticketRepository;
	
	
	@Override
	public List<Ticket> showAllTickets() {
		// TODO Auto-generated method stub
		return (List<Ticket>)ticketRepository.findAll();
	}

	@Override
	public void deleteTicket(int ticketId) {
		// TODO Auto-generated method stub
	      ticketRepository.deleteById(ticketId);		

	}
	
	

}

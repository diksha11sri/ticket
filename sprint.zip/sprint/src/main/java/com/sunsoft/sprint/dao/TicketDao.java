package com.sunsoft.sprint.dao;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;

import com.sunsoft.sprint.entity.Ticket;


public interface TicketDao {

	public List<Ticket> showAllTickets();
	public void deleteTicket(int ticketId);
}
